/**
 * returns the hash of given string
 * @param str 
 */
export function hash(str: string) {
  /* TODO */
}
